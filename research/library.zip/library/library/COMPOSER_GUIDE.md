# FL Studio Composer Agent Guide

## Overview
This guide explains how to navigate and apply the `.md` files in the `library/` directory to compose music. The files are organized into three main categories: **Harmony**, **Arrangement**, and **Vocals**.

## 1. Navigation & File Structure

```
library/
├── COMPOSER_GUIDE.md       <-- You are here
├── harmony/
│   ├── core_harmony.md     <-- Dorian, ii-V-I, Modal Interchange
│   └── global_scales.md    <-- Pentatonic, Raga, Modes, Maqam
├── arrangement/
│   ├── structure_blueprints.md <-- EDM, Pop, Symphonic structures
│   └── global_composition.md   <-- World music structures & rules
└── vocals/
    ├── prosody_stress.md   <-- Prosody, Phonetics, AI rules
    └── global_vocal_techniques.md <-- Global singing styles
```

## 2. How to Use the Files

### Step 1: Choose a Style
*   **For Western Pop/Jazz:** Load `harmony/core_harmony.md` and `arrangement/structure_blueprints.md`.
*   **For World Music:** Load `harmony/global_scales.md` and `arrangement/global_composition.md`.
*   **For Vocal-Heavy Tracks:** Load `vocals/prosody_stress.md` and `vocals/global_vocal_techniques.md`.

### Step 2: Harmony Application
*   **Dorian Mode:** Use `core_harmony.md` to select chords. Look for the **IV major chord** as a key indicator. Use the **Dorian Chord Chart** for progressions.
*   **ii-V-I:** Use the **Jazz Harmony Rules** in `core_harmony.md` for voice leading.
*   **Modal Interchange:** Use the **Borrowed Chords** table in `core_harmony.md` to add color.

### Step 3: Arrangement Application
*   **EDM:** Follow the **Standard Blueprint** in `structure_blueprints.md`. Use **16-bar** and **32-bar** phrasing.
*   **Pop:** Follow the **ABABCB** pattern. Ensure the **Hook** is in the first minute.
*   **Symphonic:** Use the **Orchestration Layers** to assign instruments.
*   **Global:** Use `global_composition.md` for **Call and Response** (West Africa) or **Maqam** (Middle East) structures.

### Step 4: Vocal Application
*   **Prosody:** Use `prosody_stress.md` to determine syllable stress. Apply **vowel modification** for high notes.
*   **Phonetics:** Use the **Consonant Articulation** rules for clarity.
*   **Global Styles:** Use `global_vocal_techniques.md` for specific styles (e.g., **Throat Singing** for Mongolian, **Melisma** for Flamenco).

## 3. Workflow for the Agent

1.  **Initialize:** Read `COMPOSER_GUIDE.md` to understand the structure.
2.  **Select Key/Mode:** Choose a key (e.g., C Major) and a mode (e.g., Dorian) based on the desired mood.
3.  **Generate Chords:** Use `core_harmony.md` to create a chord progression.
4.  **Structure the Song:** Use `structure_blueprints.md` to map out the sections (Intro, Verse, Chorus, etc.).
5.  **Compose Melody:** Use `global_scales.md` to select notes for the melody.
6.  **Apply Vocals:** Use `prosody_stress.md` to add stress and intonation to the lyrics.
7.  **Finalize:** Use `global_composition.md` to add global elements (e.g., drone, polyrhythm) if desired.

## 4. Key Rules for the Agent
*   **Consistency:** Stick to the chosen mode/key unless using modal interchange.
*   **Phrasing:** Use **4, 8, 16, or 32-bar** phrases for coherence.
*   **Dynamics:** Build energy in the build-up sections and release it in the drop/chorus.
*   **Vocal Realism:** Apply **micro-timing** and **breathiness** to the AI voice for a natural sound.

## 5. Troubleshooting
*   **If the song feels "too Western":** Check `global_scales.md` for pentatonic or modal alternatives.
*   **If the vocals sound "robotic":** Check `prosody_stress.md` for stress patterns and intonation.
*   **If the structure is "flat":** Check `structure_blueprints.md` for energy arcs and layering strategies.
